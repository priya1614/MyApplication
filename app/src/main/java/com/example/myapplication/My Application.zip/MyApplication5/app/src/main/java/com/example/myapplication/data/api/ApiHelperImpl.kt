package com.example.myapplication.data.api

class ApiHelperImpl( val apiService: ApiService) : ApiHelper {

   // override suspend fun getUsers() = apiService.getUsers()
    override suspend fun getListOfNewsArticles() = apiService.getListOfNewsArticles()


}