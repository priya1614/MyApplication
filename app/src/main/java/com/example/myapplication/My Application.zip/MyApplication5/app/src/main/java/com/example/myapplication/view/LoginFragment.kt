package com.example.myapplication.view

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.myapplication.R
import com.example.myapplication.base.BaseFragment
import com.example.myapplication.data.api.ApiHelper
import com.example.myapplication.data.api.ApiHelperImpl
import com.example.myapplication.data.api.RetrofitBuilder
import com.example.myapplication.data.model.NewsArticles
import com.example.myapplication.utils.Status
import com.example.myapplication.utils.ViewModelFactory
import com.example.myapplication.viewmodel.DashBoardViewModel

class LoginFragment : BaseFragment() {
    private lateinit var apiHelper: ApiHelper
    private lateinit var viewModel: DashBoardViewModel

    //lateinit var userName :EditText
    override fun layoutId(): Int = R.layout.fragment_login

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        setupUI()
        setupViewModel()
        setupObserver()
        return super.onCreateView(inflater, container, savedInstanceState)
    }


    private fun setupUI() {
//        recyclerView.layoutManager = LinearLayoutManager(this)
//        adapter =
//            ApiUserAdapter(
//                arrayListOf()
//            )
//        recyclerView.addItemDecoration(
//            DividerItemDecoration(
//                recyclerView.context,
//                (recyclerView.layoutManager as LinearLayoutManager).orientation
//            )
//        )
//        recyclerView.adapter = adapter
    }

    private fun setupObserver() {
        viewModel.getUsers().observe(this, Observer {
            when (it?.status) {
                Status.SUCCESS -> {
                   // Log.d("priya",""+it.data?.message())
//                    progressBar.visibility = View.GONE
//                    it.data?.let { users -> renderList(users) }
//                    recyclerView.visibility = View.VISIBLE
                }
                Status.LOADING -> {
//                    progressBar.visibility = View.VISIBLE
//                    recyclerView.visibility = View.GONE
                }
                Status.ERROR -> {
                    //Handle Error
//                    progressBar.visibility = View.GONE
//                    Toast.makeText(this, it.message, Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun renderList(users: List<NewsArticles>) {
//        adapter.addData(users)
//        adapter.notifyDataSetChanged()
    }

    private fun setupViewModel() {
       // GlobalScope.launch(Dispatchers.IO) {
            viewModel = ViewModelProvider(
                this,
                ViewModelFactory(
                    ApiHelperImpl(RetrofitBuilder.apiService)
                )
            ).get(DashBoardViewModel::class.java)
        }


}