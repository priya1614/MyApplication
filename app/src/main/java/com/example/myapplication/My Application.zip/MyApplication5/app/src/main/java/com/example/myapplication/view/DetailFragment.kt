package com.example.myapplication.view

class DetailFragment {
}