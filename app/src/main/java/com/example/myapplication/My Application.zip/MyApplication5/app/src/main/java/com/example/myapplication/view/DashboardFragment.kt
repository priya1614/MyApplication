package com.example.myapplication.view

import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.View
import android.widget.Toast
import com.example.myapplication.R
import com.example.myapplication.adapter.NewsArticleAdapter
import com.example.myapplication.base.BaseFragment
import com.example.myapplication.data.api.ApiHelperImpl
import com.example.myapplication.data.api.RetrofitBuilder
import com.example.myapplication.data.model.NewsArticles
import com.example.myapplication.utils.Status
import com.example.myapplication.utils.ViewModelFactory
import com.example.myapplication.viewmodel.DashBoardViewModel

class DashboardFragment:BaseFragment() {
    override fun layoutId(): Int = R.layout.fragment_dashboard

    lateinit var viewModel: DashBoardViewModel
    private lateinit var adapter: NewsArticleAdapter
    var recyclerView : RecyclerView?= null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        recyclerView = view?.findViewById(R.id.news_list_rv)
        setupUI()
        setupViewModel()
        setupObserver()
    }

    private fun setupUI() {
        recyclerView?.layoutManager =
            LinearLayoutManager(context)
        adapter =
            NewsArticleAdapter(
                arrayListOf()
            )
        recyclerView?.addItemDecoration(
            DividerItemDecoration(
                recyclerView?.context,
                (recyclerView?.layoutManager as LinearLayoutManager).orientation
            )
        )
        recyclerView?.adapter = adapter
    }

    private fun setupObserver() {
        viewModel.getUsers().observe(this, Observer {
            when (it?.status) {
                Status.SUCCESS -> {
                    //progressBar.visibility = View.GONE
                    it.data?.let { users -> renderList(users) }
                    recyclerView?.visibility = View.VISIBLE
                }
                Status.LOADING -> {
                    //progressBar.visibility = View.VISIBLE
                    recyclerView?.visibility = View.GONE
                }
                Status.ERROR -> {
                    //Handle Error
                    //progressBar.visibility = View.GONE
                    Toast.makeText(context, it.message, Toast.LENGTH_LONG).show()
                }
            }
        })
    }

    private fun renderList(users: List<NewsArticles>) {
        adapter.addData(users)
        adapter.notifyDataSetChanged()
    }

    private fun setupViewModel() {
        viewModel = ViewModelProvider(
            this,
            ViewModelFactory(
                ApiHelperImpl(RetrofitBuilder.apiService)
            )
        ).get(DashBoardViewModel::class.java)
    }
}