package com.example.myapplication.data.model

import com.google.gson.annotations.SerializedName

data class NewsArticles(

    @SerializedName("content")
    val content: String = "",
    @SerializedName("url")
    val url: String = "",
    @SerializedName("title")
    val title: String = "",
    @SerializedName("author")
    val author: String = "",
    @SerializedName("description")
    val description: String = "",
    @SerializedName("publishedAt")
    val publishedAt: String = ""


//    @SerializedName("uidata")
//    val uiData: UiData = UiData("","","","")

)